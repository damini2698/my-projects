/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.UUID;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author pria
 */
@WebServlet(urlPatterns = {"/missindbms"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2,
        maxFileSize = 1024 * 1024 * 10,
        maxRequestSize = 50 * 1024 * 1024)
public class missindbms extends HttpServlet {
private static final String SAVE_DIR="images";
  static String savePath="F:\\Advance java\\Person Identification\\web\\" + File.separator + SAVE_DIR;
     
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       PrintWriter out = response.getWriter(); 
       File fileSaveDir=new File(savePath);
        String name=request.getParameter("name");
        String gender=request.getParameter("gender");
        String age=request.getParameter("age");
        String height=request.getParameter("height");
        String weight=request.getParameter("weight");
        String last=request.getParameter("last");
        Part part=request.getPart("file");
        String fileName=UUID.randomUUID().toString();
        part.write(savePath + File.separator + fileName);
        
        try
        {
            String connectionURL="jdbc:mysql://localhost:3306/person";
  
                    Class.forName("com.mysql.jdbc.Driver");
                   Connection con=DriverManager.getConnection(connectionURL, "root","root");
            String insertquery="insert into missing(name,gender,age,height,weight,lastseen,image) values(?,?,?,?,?,?,?)";
              PreparedStatement pst= con.prepareStatement(insertquery);
            pst.setString(1,name);
              pst.setString(2,gender);
              pst.setString(3,age);
              pst.setString(4,height);
               pst.setString(5,weight);
                pst.setString(6,last);
                pst.setString(7,fileName);
                pst.executeUpdate();
                out.println("<center><h1>Image inserted successfully...</h1><center>");
                
               
        }
        catch(Exception e)
        {
         out.println(e);   
        }}
        
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}



